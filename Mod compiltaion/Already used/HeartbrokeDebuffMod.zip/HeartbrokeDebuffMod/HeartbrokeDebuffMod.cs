using Terraria.ModLoader;

namespace HeartbrokeDebuffMod
{
	public class HeartbrokeDebuffMod : Mod
	{
	}
}