using Terraria.ModLoader;

namespace LagannaEnemy
{
	public class LagannaEnemy : Mod
	{
	}
}