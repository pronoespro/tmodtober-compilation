using Terraria.ModLoader;

namespace BardTerrarian
{
	public class BardTerrarian : Mod
	{

		public static BardTerrarian Instance;

        public override void Load()
        {
            Instance = this;
            SingKeybind = KeybindLoader.RegisterKeybind(this, "Sing", "Q");
            base.Load();
        }

        public override void Unload()
        {
            Instance = null;
            SingKeybind = null;
            base.Unload();
        }


        public static ModKeybind SingKeybind;

    }
}