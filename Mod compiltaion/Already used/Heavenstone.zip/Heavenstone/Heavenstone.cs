using Terraria.ModLoader;

namespace Heavenstone
{
	public class Heavenstone : Mod
	{
	}
}