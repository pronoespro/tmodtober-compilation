using Terraria.ModLoader;

namespace PlayerParty
{
	public class PlayerParty : Mod
	{

		public static int PartyChance;


    }
}