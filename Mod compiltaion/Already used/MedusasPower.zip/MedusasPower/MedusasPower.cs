using Terraria.ModLoader;

namespace MedusasPower
{
	public class MedusasPower : Mod
	{
	}
}