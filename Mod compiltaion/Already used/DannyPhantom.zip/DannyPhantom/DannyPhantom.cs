using Terraria;
using Terraria.ModLoader;
using Terraria.DataStructures;
using Terraria.ID;

namespace DannyPhantom
{
	public class DannyPhantom : Mod
	{

		public static ModKeybind TriggerPowersKeybind;

        public static int PlayerInvisibilityLegsTexture, PlayerInvisibilityHeadTexture, PlayerInvisibilityFaceTexture, PlayerInvisibilityTorsoTexture;

        public override void Unload()
        {
            TriggerPowersKeybind = null;

        }

        public override void Load()
        {
            TriggerPowersKeybind = KeybindLoader.RegisterKeybind(this, "Trigger Phantom Powers (if available)", "Q");

            PlayerInvisibilityTorsoTexture = EquipLoader.AddEquipTexture(this, "DannyPhantom/PlayerSprites/invisibleTorso", EquipType.Body, name: "flameBody");
            PlayerInvisibilityLegsTexture = EquipLoader.AddEquipTexture(this, "DannyPhantom/PlayerSprites/InvisibleLegs", EquipType.Legs, name: "invisibleHead");
            PlayerInvisibilityFaceTexture = EquipLoader.AddEquipTexture(this, "DannyPhantom/PlayerSprites/InvisibleLegs", EquipType.Face, name: "invisibleFace");
            PlayerInvisibilityHeadTexture = EquipLoader.AddEquipTexture(this, "DannyPhantom/PlayerSprites/InvisibleLegs", EquipType.Head, name: "invisibleLegs");
        }

    }
}