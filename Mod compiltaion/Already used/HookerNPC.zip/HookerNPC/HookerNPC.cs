using Terraria.ModLoader;

namespace HookerNPC
{
	public class HookerNPC : Mod
	{
	}
}