using Terraria.ModLoader;

namespace granite_puncher_gun
{
	public class granite_puncher_gun : Mod
	{
	}
}