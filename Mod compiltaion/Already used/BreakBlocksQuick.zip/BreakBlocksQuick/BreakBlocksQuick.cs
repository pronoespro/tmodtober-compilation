using Terraria.ModLoader;

namespace BreakBlocksQuick
{
	public class BreakBlocksQuick : Mod
	{


	}
}