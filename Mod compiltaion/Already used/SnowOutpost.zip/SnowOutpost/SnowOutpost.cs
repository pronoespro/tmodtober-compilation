using Terraria.ModLoader;

namespace SnowOutpost
{
	public class SnowOutpost : Mod
	{

        public static SnowOutpost Instance;

        public override void Load()
        {
            Instance = this;
            base.Load();
        }

        public override void Unload()
        {
            Instance = null;
            base.Unload();
        }

    }
}