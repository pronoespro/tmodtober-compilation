using Terraria.ModLoader;

namespace GhostRaid
{
	public class GhostRaid : Mod
	{

	}
}