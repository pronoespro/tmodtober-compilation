using Terraria.ModLoader;

namespace SpiritCritter
{
	public class SpiritCritter : Mod
	{
	}
}