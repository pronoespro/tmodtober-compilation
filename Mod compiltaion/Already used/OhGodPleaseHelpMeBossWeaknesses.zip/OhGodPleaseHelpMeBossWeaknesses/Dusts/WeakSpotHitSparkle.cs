﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Terraria.DataStructures;
using Microsoft.Xna.Framework;

namespace OhGodPleaseHelpMeBossWeaknesses.Dusts
{
    public class WeakSpotHitSparkle:ModDust
    {

        float initScale = 5f;

        public override void OnSpawn(Dust dust)
        {
            dust.scale = initScale;
        }

        public override bool Update(Dust dust)
        {

            int frameX =(int)( dust.scale % (initScale / 4f));
            int frameY = 1-(int)(dust.scale / (initScale));
            dust.frame = new Rectangle(frameX*8, frameY*8, 8, 8);

            dust.rotation += 0.1f;
            dust.scale -= 0.25f;
            dust.noLight = false;
            dust.noLightEmittence = false;

            dust.position += dust.velocity;

            if (dust.scale < 0.25f)
                dust.active = false;

            return false;
        }

    }
}
