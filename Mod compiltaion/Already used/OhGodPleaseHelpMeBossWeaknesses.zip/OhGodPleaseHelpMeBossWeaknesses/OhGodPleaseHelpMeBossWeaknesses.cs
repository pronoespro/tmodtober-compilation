using Terraria.ModLoader;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using System.Collections.Generic;

namespace OhGodPleaseHelpMeBossWeaknesses
{
	public class OhGodPleaseHelpMeBossWeaknesses : Mod
	{

		public void AddWeaknessToEnemy(NPC npc,string name,Vector2 position,float range,int type,bool _scaleWithNPC=false)
        {
			BossWeaknessOverride weaknessNPC = npc.GetGlobalNPC<BossWeaknessOverride>();

            if (weaknessNPC.weakSpots == null)
            {
				weaknessNPC.weakSpots = new List<WeakSpot>();
            }

			WeakSpot _newSpot = new WeakSpot(name, position, range, (WeakSpotType)MathHelper.Clamp(type,0,4), _scaleWithNPC);
			weaknessNPC.weakSpots.Add(_newSpot);
        }


	}
}