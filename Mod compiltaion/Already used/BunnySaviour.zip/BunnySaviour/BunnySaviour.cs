using Terraria.ModLoader;

namespace BunnySaviour
{
	public class BunnySaviour : Mod
	{
	}
}