using Terraria.ModLoader;

namespace CrossWeapon
{
	public class CrossWeapon : Mod
	{
	}
}