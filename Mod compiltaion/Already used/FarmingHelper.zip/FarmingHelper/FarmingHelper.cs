using Terraria.ModLoader;

namespace FarmingHelper
{
	public class FarmingHelper : Mod
	{
	}
}