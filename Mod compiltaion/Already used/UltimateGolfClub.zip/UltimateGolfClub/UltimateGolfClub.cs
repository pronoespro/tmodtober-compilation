using Terraria.ModLoader;

namespace UltimateGolfClub
{
	public class UltimateGolfClub : Mod
	{
	}
}