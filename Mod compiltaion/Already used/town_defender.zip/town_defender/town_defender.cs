using Terraria.ModLoader;

namespace town_defender
{
	public class town_defender : Mod
	{
	}
}