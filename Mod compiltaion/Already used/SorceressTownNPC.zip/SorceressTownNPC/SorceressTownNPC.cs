using Terraria.ModLoader;

namespace SorceressTownNPC
{
	public class SorceressTownNPC : Mod
	{
	}
}