using Terraria.ModLoader;

namespace StarBullet
{
	public class StarBulletMod : Mod
	{
	}
}