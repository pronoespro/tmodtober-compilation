using Terraria.ModLoader;

namespace PaintbrushUpgrade
{
	public class PaintbrushUpgrade : Mod
	{
	}
}