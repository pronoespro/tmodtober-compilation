using Terraria.ModLoader;

namespace LivingFireFurniture
{
	public class LivingFireFurniture : Mod
	{
	}
}