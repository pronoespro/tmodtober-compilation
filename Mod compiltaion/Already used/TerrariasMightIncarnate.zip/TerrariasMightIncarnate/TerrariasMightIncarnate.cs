using Terraria.ModLoader;
using Microsoft.Xna.Framework.Input;

namespace TerrariasMightIncarnate
{
	public class TerrariasMightIncarnate : Mod
	{

		public static ModKeybind mightTriggerKeybing;

        public override void Load()
        {
            base.Load();
            mightTriggerKeybing = KeybindLoader.RegisterKeybind(this, "Terraria Trigger", Keys.Q);
        }

        public override void Unload()
        {
            base.Unload();
            mightTriggerKeybing = null;
        }

    }
}