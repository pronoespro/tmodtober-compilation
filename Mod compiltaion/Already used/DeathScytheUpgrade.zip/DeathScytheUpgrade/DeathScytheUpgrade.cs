using Terraria.ModLoader;

namespace DeathScytheUpgrade
{
	public class DeathScytheUpgrade : Mod
	{

		public static int PlayerInvisibilityLegsTexture, PlayerInvisibilityHeadTexture, PlayerInvisibilityFaceTexture;
		public static int PlayerFlameTexture;

        public override void Load()
        {
            base.Load();

            PlayerFlameTexture = EquipLoader.AddEquipTexture(this, "DeathScytheUpgrade/PlayerSprites/flameTorso", EquipType.Body, name: "flameBody");
            PlayerInvisibilityLegsTexture = EquipLoader.AddEquipTexture(this, "DeathScytheUpgrade/PlayerSprites/InvisibleLegs", EquipType.Legs, name: "invisibleHead");
            PlayerInvisibilityFaceTexture = EquipLoader.AddEquipTexture(this, "DeathScytheUpgrade/PlayerSprites/InvisibleLegs", EquipType.Face, name: "invisibleFace");
            PlayerInvisibilityHeadTexture = EquipLoader.AddEquipTexture(this, "DeathScytheUpgrade/PlayerSprites/InvisibleLegs", EquipType.Head, name: "invisibleLegs");
        }

    }
}