using Terraria.ModLoader;

namespace MoonHeart
{
	public class MoonHeartMod : Mod
	{
	}
}