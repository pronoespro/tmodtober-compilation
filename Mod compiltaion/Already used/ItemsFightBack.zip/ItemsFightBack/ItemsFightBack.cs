using Terraria.ModLoader;

namespace ItemsFightBack
{
	public class ItemsFightBack : Mod
	{
	}
}