using Terraria.ModLoader;

namespace GolemQuickRework
{
	public class GolemQuickRework : Mod
	{
	}
}