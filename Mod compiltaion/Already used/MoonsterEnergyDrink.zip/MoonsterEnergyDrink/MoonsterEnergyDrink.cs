using Terraria.ModLoader;

namespace MoonsterEnergyDrink
{
	public class MoonsterEnergyDrink : Mod
	{
	}
}