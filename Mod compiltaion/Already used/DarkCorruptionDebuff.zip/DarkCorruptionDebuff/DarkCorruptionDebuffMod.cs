using Terraria.ModLoader;

namespace DarkCorruptionDebuff
{
	public class DarkCorruptionDebuffMod : Mod
	{
	}
}