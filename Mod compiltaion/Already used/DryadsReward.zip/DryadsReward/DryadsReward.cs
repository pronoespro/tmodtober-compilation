using Terraria.ModLoader;

namespace DryadsReward
{
	public class DryadsReward : Mod
	{

		public static ModKeybind TriggerBlessing;

        public override void Unload()
        {
            TriggerBlessing = null;

        }

        public override void Load()
        {
            TriggerBlessing = KeybindLoader.RegisterKeybind(this, "Trigger Blessing (if available)", "Q");
        }

    }
}